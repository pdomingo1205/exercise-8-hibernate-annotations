package com.pdomingo.service;


import java.util.*;
import java.util.stream.Collectors;
import com.pdomingo.model.person.*;
import com.pdomingo.model.role.Role;
import com.pdomingo.dao.PersonDaoImpl;
import org.hibernate.NonUniqueObjectException;

public class PersonService {

	private static PersonDaoImpl personDaoImpl;

	public PersonService() {
		personDaoImpl = new PersonDaoImpl();
	}

	public PersonService(PersonDaoImpl newDao) {
		personDaoImpl = newDao;
	}

	public String saveOrUpdate(Person entity) {
		String updateStatus;
		try{
			personDaoImpl.saveOrUpdate(entity);
			updateStatus = "\n\t !!! Save Person Success !!!";
		}catch(Exception e){
			updateStatus = "\n\t !-- Save Person Failed --!";
		}
		return updateStatus;
	}

	public String update(Person entity) {
		String updateStatus;
		try{
			personDaoImpl.update(entity);
			updateStatus = "\n\t !!! Update Person Successful !!!";
		}
		catch(Exception e){
			updateStatus = "\n\t !-- Update Person Failed --!";
		}
		return updateStatus;
	}

	public Set<Role> removeRole(Set<Role> roles, String roleName){
		for (Iterator<Role> iterator = roles.iterator(); iterator.hasNext();) {
		    Role role  =  iterator.next();
		    if (role.getRole().equals(roleName)) {
		        iterator.remove();
		    }
		}
		return roles;
	}


	public Set<ContactInfo> removeContact(Set<ContactInfo> contacts, Long id){
		for (Iterator<ContactInfo> iterator = contacts.iterator(); iterator.hasNext();) {
			ContactInfo contact  =  iterator.next();
			if (contact.getContactInfoId().equals(id)) {
				iterator.remove();
			}
		}
		return contacts;
	}

	public Boolean containsRole(Set<Role> list, String name){
    	return list.stream().filter(o -> o.getRole().equals(name)).findFirst().isPresent();
	}

	public Person findById(Long id) {
		Person person = personDaoImpl.findById(id);

		return person;
	}

	public Boolean checkIfExists(Long Id){
		Boolean exists = true;

		Person person = personDaoImpl.findById(Id);

		if(person == null){
			exists = false;
		}

		return exists;
	}

	public String delete(Long id) {

		String textToReturn;
		try{
			Person person = personDaoImpl.findById(id);
			person.getName();

			personDaoImpl.delete(person);
			textToReturn = "\n\t!!! Deleted !!!\n";

		}catch(Exception e){
			textToReturn = "\n\t!-- Delete Failed --!\n";
		}

		return textToReturn;
	}

	public List<Person> findAll() {
		List<Person> persons = personDaoImpl.findAll();
		return persons;
	}

	public List<Person> findOrderBy(String field, Integer order) {

		String stringOrder = order.equals(1)? "ASC": "DESC";
		List<Person> persons = personDaoImpl.findAllOrderBy(field, stringOrder);

		return persons;
	}


	public List<Role> findPersonRoles(Long id){
		List<Role> roles = personDaoImpl.findPersonRoles(id);
		return roles;
	}

	public List<String> findPersonContacts(Long id){
		List<ContactInfo> contacts = personDaoImpl.findPersonContacts(id);

		List<String> contactString = new ArrayList<String>();

		for (ContactInfo contact : contacts) {
			contactString.add(contact.toString());
		}

		return contactString;
	}
}
