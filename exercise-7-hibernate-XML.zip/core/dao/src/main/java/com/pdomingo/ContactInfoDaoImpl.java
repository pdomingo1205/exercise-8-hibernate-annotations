package com.pdomingo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import org.hibernate.MappingException;
import org.hibernate.Query;


import com.pdomingo.model.person.ContactInfo;

public class ContactInfoDaoImpl implements DaoInterface<ContactInfo, Long> {

	private Session currentSession;

	private Transaction currentTransaction;

	public ContactInfoDaoImpl(){
	}
	public  Session openCurrentSession() {
		currentSession = DaoConfig.getSessionFactory().openSession();
		return currentSession;
	}

	public  Session openCurrentSessionwithTransaction() {
		currentSession = DaoConfig.getSessionFactory().openSession();
		currentTransaction = currentSession.beginTransaction();
		return currentSession;
	}

	public  void closeCurrentSession() {
		currentSession.close();
	}

	public  void closeCurrentSessionwithTransaction() {
		currentTransaction.commit();
		currentSession.close();
	}

	public  Session getCurrentSession() {
		return currentSession;
	}

	public  void setCurrentSession(Session currentSession) {
		this.currentSession = currentSession;
	}

	public  Transaction getCurrentTransaction() {
		return currentTransaction;
	}

	public  void setCurrentTransaction(Transaction currentTransaction) {
		this.currentTransaction = currentTransaction;
	}
	public void saveOrUpdate(ContactInfo entity) {
		openCurrentSessionwithTransaction();
		currentSession.saveOrUpdate(entity);
		closeCurrentSessionwithTransaction();
	}

	public void update(ContactInfo entity) {
		openCurrentSessionwithTransaction();
		currentSession.update(entity);
		closeCurrentSessionwithTransaction();
	}

	public ContactInfo findById(Long id) {
		openCurrentSessionwithTransaction();
		ContactInfo contactInfo = (ContactInfo) currentSession.get(ContactInfo.class, id);
		closeCurrentSessionwithTransaction();
		return contactInfo;
	}

	public ContactInfo findContact(ContactInfo contact) {
		openCurrentSessionwithTransaction();
		List<ContactInfo> list = currentSession.createCriteria(ContactInfo.class).list();
		closeCurrentSessionwithTransaction();
		return list.get(list.indexOf(contact));
	}

	public void delete(ContactInfo entity) {
		openCurrentSessionwithTransaction();
		currentSession.delete(entity);
		closeCurrentSessionwithTransaction();
	}

	@SuppressWarnings("unchecked")
	public List<ContactInfo> findAll() {
		openCurrentSessionwithTransaction();
		List<ContactInfo> contactInfos = (List<ContactInfo>) currentSession.createQuery("from ContactInfo").list();
		closeCurrentSessionwithTransaction();
		return contactInfos;
	}

}
