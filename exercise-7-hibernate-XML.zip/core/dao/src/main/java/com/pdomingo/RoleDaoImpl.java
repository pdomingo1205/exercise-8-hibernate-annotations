package com.pdomingo.dao;

import java.util.List;

import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.Criteria;
import org.hibernate.MappingException;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;

import com.pdomingo.model.role.Role;

public class RoleDaoImpl implements DaoInterface<Role, Long> {

	private Session currentSession;

	private Transaction currentTransaction;

	public RoleDaoImpl(){
	}
	public  Session openCurrentSession() {
		currentSession = DaoConfig.getSessionFactory().openSession();
		return currentSession;
	}

	public  Session openCurrentSessionwithTransaction() {
		currentSession = DaoConfig.getSessionFactory().openSession();
		currentTransaction = currentSession.beginTransaction();
		return currentSession;
	}

	public  void closeCurrentSession() {
		currentSession.close();
	}

	public  void closeCurrentSessionwithTransaction() {
		currentTransaction.commit();
		currentSession.close();
	}

	public  Session getCurrentSession() {
		return currentSession;
	}

	public  void setCurrentSession(Session currentSession) {
		this.currentSession = currentSession;
	}

	public  Transaction getCurrentTransaction() {
		return currentTransaction;
	}

	public  void setCurrentTransaction(Transaction currentTransaction) {
		this.currentTransaction = currentTransaction;
	}


	public void saveOrUpdate(Role entity) {
		openCurrentSessionwithTransaction();
		currentSession.saveOrUpdate(entity);
		closeCurrentSessionwithTransaction();
	}

	public void update(Role entity) {
		openCurrentSessionwithTransaction();
		currentSession.update(entity);
		closeCurrentSessionwithTransaction();
	}

	public Role findById(Long id) {
		openCurrentSessionwithTransaction();
		Role role = (Role) currentSession.get(Role.class, id);
		closeCurrentSessionwithTransaction();
		return role;
	}

	public Role findRole(Role role) {
		openCurrentSessionwithTransaction();
		List<Role> list = currentSession.createCriteria(Role.class).list();
		closeCurrentSessionwithTransaction();
		return list.get(list.indexOf(role));
	}

	public void delete(Role entity) {
		openCurrentSessionwithTransaction();
		currentSession.delete(entity);
		closeCurrentSessionwithTransaction();
	}

	public Role findByRoleName(String roleName){
		Role role = new Role();
		openCurrentSessionwithTransaction();
		try{
			Query query= currentSession.createQuery("from Role where role=:name");
			query.setParameter("name", roleName);
			role = (Role) query.uniqueResult();
		}catch(Exception e){

		}
		closeCurrentSessionwithTransaction();
		return role;
	}


	@SuppressWarnings("unchecked")
	public List<Role> findAll() {
		openCurrentSessionwithTransaction();
		List<Role> roles = (List<Role>) currentSession.createQuery("from Role").list();
		closeCurrentSessionwithTransaction();
		return roles;
	}

	public void deleteAll() {
		openCurrentSessionwithTransaction();
		List<Role> entityList = findAll();
		for (Role entity : entityList) {
			delete(entity);
		}
		closeCurrentSessionwithTransaction();

	}


}
