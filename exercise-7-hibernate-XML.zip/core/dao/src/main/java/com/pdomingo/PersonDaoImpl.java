package com.pdomingo.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.Transaction;

import org.hibernate.MappingException;
import org.hibernate.Query;


import com.pdomingo.model.person.*;
import com.pdomingo.model.role.Role;

public class PersonDaoImpl implements DaoInterface<Person, Long> {

	private Session currentSession;

	private Transaction currentTransaction;

	public PersonDaoImpl(){
	}

	public  Session openCurrentSession() {
		currentSession = DaoConfig.getSessionFactory().openSession();
		return currentSession;
	}

	public  Session openCurrentSessionwithTransaction() {
		currentSession = DaoConfig.getSessionFactory().openSession();
		currentTransaction = currentSession.beginTransaction();
		return currentSession;
	}

	public  void closeCurrentSession() {
		currentSession.close();
	}

	public  void closeCurrentSessionwithTransaction() {
		currentTransaction.commit();
		currentSession.close();
	}

	public  Session getCurrentSession() {
		return currentSession;
	}

	public  void setCurrentSession(Session currentSession) {
		this.currentSession = currentSession;
	}

	public  Transaction getCurrentTransaction() {
		return currentTransaction;
	}

	public  void setCurrentTransaction(Transaction currentTransaction) {
		this.currentTransaction = currentTransaction;
	}

	public void saveOrUpdate(Person entity) {
			openCurrentSessionwithTransaction();
			currentSession.saveOrUpdate(entity);
			closeCurrentSessionwithTransaction();
	}

	public void update(Person entity) {
		openCurrentSessionwithTransaction();
		currentSession.update(entity);
		closeCurrentSessionwithTransaction();
	}

	public void updateRole(Person entity) {
		openCurrentSessionwithTransaction();

		currentSession.update(entity);
		Person person = findById(entity.getPersonId());
		currentSession.evict(person);
		person = entity;
		currentSession.merge(person);

		closeCurrentSessionwithTransaction();
	}

	public Person findById(Long id) {
		openCurrentSessionwithTransaction();
		Person person = (Person) currentSession.get(Person.class, id);
		closeCurrentSessionwithTransaction();
		return person;
	}

	public Person findPerson(Person person) {
		openCurrentSessionwithTransaction();
		List<Person> list = currentSession.createCriteria(Person.class).list();
		closeCurrentSessionwithTransaction();

		return list.get(list.indexOf(person));

	}

	public void delete(Person entity) {
		openCurrentSessionwithTransaction();
		currentSession.delete(entity);
		closeCurrentSessionwithTransaction();
	}

	@SuppressWarnings("unchecked")
	public List<Person> findAll() {
		openCurrentSessionwithTransaction();
		List<Person> persons = (List<Person>) currentSession.createQuery("from Person").list();
		closeCurrentSessionwithTransaction();
		return persons;
	}

	public List<Person> findAllOrderBy(String field, String order) {
		openCurrentSessionwithTransaction();
		List<Person> persons = (List<Person>) currentSession.createQuery(String.format("from Person ORDER BY %s %s", field, order)).list();
		closeCurrentSessionwithTransaction();
		return persons;
	}

	@SuppressWarnings("unchecked")
	public List<Role> findPersonRoles(Long id) {
		openCurrentSessionwithTransaction();
		List<Role> roles = (List<Role>) currentSession.createQuery("select role from Person person join person.roles role where person.personId = "+id).list();
		closeCurrentSessionwithTransaction();
		return roles;
	}

	@SuppressWarnings("unchecked")
	public List<ContactInfo> findPersonContacts(Long id) {
		openCurrentSessionwithTransaction();
		List<ContactInfo> roles = (List<ContactInfo>) currentSession.createQuery("from ContactInfo where person.personId = "+id).list();
		closeCurrentSessionwithTransaction();
		return roles;
	}


}
