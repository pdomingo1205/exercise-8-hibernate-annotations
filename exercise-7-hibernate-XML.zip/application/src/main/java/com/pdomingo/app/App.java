package com.pdomingo.app;

import java.io.IOException;
import java.util.*;


import com.pdomingo.model.role.*;
import com.pdomingo.model.person.*;
import com.pdomingo.service.*;
//import org.apache.log4j.Logger;


public class App {
//final static Logger logger = Logger.getLogger(App.class);

	public static void main(String[] args) {

		Menu menu = new Menu();
		menu.start();

	}

}
