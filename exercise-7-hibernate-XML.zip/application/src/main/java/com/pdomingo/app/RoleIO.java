package com.pdomingo.app;

import java.io.IOException;
import java.util.*;
import java.text.*;

import org.apache.commons.lang3.StringUtils;
import com.pdomingo.model.role.*;
import com.pdomingo.model.person.*;
import com.pdomingo.service.*;
import com.pdomingo.util.*;

import com.pdomingo.util.InputValidation;



public class RoleIO {
	RoleService roleService = new RoleService();

	public RoleIO(){

	}

	public static void clearScreen() {
	    System.out.print("\033[H\033[2J");
	    System.out.flush();
	}

	public void start(){
		Integer choice;
		do{
			choice = chooseOperation();
			doChooseOperation(choice);
		}while(choice != 4);
	}

	public Integer chooseOperation(){

		System.out.println("\n\t--- Choose Operation --- \n");
		System.out.println("\n\t 1. Create Role");
		System.out.println("\n\t 2. Update Role");
		System.out.println("\n\t 3. Delete Role");
		System.out.println("\n\t 4. Back");

		return InputValidation.getIntegerInRange(1,4);
	}

	public void doChooseOperation(Integer choice){

		switch(choice){
			case 1:
				createRole();
				break;
			case 2:
				updateRole();
				break;
			case 3:
				deleteRole();
				break;
			case 4:
				break;
		}

	}


	public Role addRole(){
		Role role = new Role();
		String roleName = askRole();


		Role existingRole = roleService.checkIfUnique(roleName);
		role = existingRole;
        return role;
	}


	public Role listAndGetInput(){
		Long input;
		Role role = null;
		try{
			List<Role> roles = roleService.findAll();
			listRoles();
			roles.get(0);
			input = Long.valueOf(InputValidation.getIntegerInRange(1, roles.size()));
			role = roles.get(input.intValue()-1);
		}catch(Exception e){

		}
		return role;
	}

	public void createRole(){
		Role role = new Role();
		String roleName = askRole().toUpperCase();

		role = roleService.checkIfUnique(roleName);

        System.out.println(roleService.saveOrUpdate(role));
	}

	private String askRole(){

		System.out.println("\n \t--- Input name of Role ---\n");

		String inputRole = InputValidation.getRequiredInput();

		return inputRole;
	}


	public void updateRole(){
		try{
			System.out.println("\n\t--- Input ID of role to update---\n");
			Role role = listAndGetInput();

				System.out.println("\n\t--- Input new Role ---\n");
				String newRole = InputValidation.getRequiredInput().toUpperCase();

					if(roleService.checkIfNameExists(newRole)){
						System.out.println("Role Already Exists");
					}else{
						role.setRole(newRole);
						System.out.println(roleService.update(role));

					}

		}catch(Exception e ){
			System.out.println("\n\t!-- Update Failed --!\n");
		}


		}


	public void deleteRole(){
		try{
			System.out.println("\n\t--- Input ID of role to delete *Use List to find ID's ---\n");
			Role role = listAndGetInput();


			String message = roleService.delete(role.getRoleId());
			System.out.println(message);

			if(message.equals("\n\t!-- Another Person is still assigned to this Role --!\n")){
				System.out.println(getRoleOwners(roleService.findById(role.getRoleId())));
			}

		}catch(Exception e ){
			System.out.println("\n\t!-- Update Failed --!\n");
		}


	}

	int index;

	public void listRoles(){
		index = 1;
		for (Role r : roleService.findAll()) {
			System.out.println((index++) +": "+r.getRole());
		}
	}

	private String getRoleOwners(Role role) {
		StringBuilder sb = new StringBuilder();
		role.getPersons().stream()
						   .sorted((p1,p2) -> Long.compare(p1.getPersonId(), p2.getPersonId()))
		                   .forEach(person -> sb.append(String.format("%s: %s \n", person.getPersonId(), person.getName())));
		return sb.toString();
	}




}
